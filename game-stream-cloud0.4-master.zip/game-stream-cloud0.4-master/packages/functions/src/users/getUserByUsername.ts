import { DynamoDB } from "aws-sdk";
import {Table} from 'sst/node/table'
import User from "./User";

const dynamoDB = new DynamoDB.DocumentClient()

export default async function getUser(username: string) : Promise<User | undefined>{
    const params = {
        Key:{username: username},
        TableName: Table.UserTable.tableName
    }

    const {Item} = await dynamoDB.get(params).promise()

    return Item as User
}