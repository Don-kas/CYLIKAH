import {DynamoDB} from 'aws-sdk'
import {Table} from 'sst/node/table'
import User from './User'

const dynamoDB = new DynamoDB.DocumentClient()

export default async function CreateUser(newUser: User): Promise<User>{
    const params = {
        Item: newUser as Record<string, unknown>,
        TableName: Table.UserTable.tableName
    }

    await dynamoDB.put(params).promise()

    return newUser
}