import User from "./User"
import getUsetByUsername from './getUserByUsername'
import createUser from './createUser'

type AppSyncEvent = {
    info:{
        fieldName: string
    }
    arguments:{
        newUser:    User,
        username:   string
    }
}

export async function handler(event: AppSyncEvent)
: Promise<Record<string, unknown>[] | User | string | null | undefined>{
    switch(event.info.fieldName){
        case 'getUserByUsername':
            return getUsetByUsername(event.arguments.username)
        case 'createUser':
            return createUser(event.arguments.newUser)
        default:
            return null
    }
}