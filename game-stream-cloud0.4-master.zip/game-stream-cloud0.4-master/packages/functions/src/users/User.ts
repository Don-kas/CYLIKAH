import Stream from "../stream/stream"

type User = {
    username:     string,
    email:        string,
    phone:        string,
    lostTimeMs:   number,
    remoteDesc:   string,
    recentStream: Stream
}

export default User