import User from '../users/User'
import Product from '../products/Product'

type Stream = {
    id:                 string,
    client1:            User,
    client2:            User,
    product:            Product,
    startTimeMs:        number,
    durationMs:         number,
    streamedDurationMs: number
    
}

export default Stream