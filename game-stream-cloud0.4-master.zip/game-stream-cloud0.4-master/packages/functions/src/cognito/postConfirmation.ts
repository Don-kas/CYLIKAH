export default function handler(event: any){
    console.log(event)
}