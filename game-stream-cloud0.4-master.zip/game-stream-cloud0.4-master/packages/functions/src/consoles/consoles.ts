export enum ConsoleType{
    Playstation4,
    PC
}