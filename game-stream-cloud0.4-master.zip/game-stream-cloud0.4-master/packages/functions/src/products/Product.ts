import User from '../users/User'
import {ConsoleType} from '../consoles/consoles'

type Product = {
    id:               string,
    owner:            User,
    name:             string,
    description:      string,
    consoleType:      ConsoleType,
    maxClients:       number,
    hourlyRate:       number,
    sessionLenthMs:   number,
    rating:           number
}

export default Product