import { StackContext, NextjsSite, Cognito, Table, AppSyncApi } from "sst/constructs";

export default function main({ stack }: StackContext){
    const site = new NextjsSite(stack, 'main-site')

    const usersTable = new Table(stack, 'UserTable',{
        fields:{
            id: 'string',
            username:'string'
        },
        primaryIndex:{partitionKey:'id'},
        globalIndexes:{
            usernameIndex:{partitionKey:'username'}
        }
    })
    const productsTable = new Table(stack, 'PoductsTable',{
        fields:{
            id:'string',
            owner:'string'
        },
        primaryIndex:{partitionKey:'owner', sortKey:'id'}
    })

    const api = new AppSyncApi(stack, 'appSyncApi',{
        schema:'packages/functions/src/graphql/schema.graphql',
        defaults:{
            function:{
                bind:[usersTable, productsTable]
            }
        },
        dataSources:{
            users: 'packages/functions/src/users/main.handler'
        },
        resolvers:{
            'Mutation         createUser':'users',
            'Query     getUserByUsername':'users',
        }
    })
    
    // const auth = new Cognito(stack, 'Auth',{
    //     login:['preferredUsername', 'username'],
    //     triggers:{
    //         postConfirmation:{
    //             handler:'packages/functions/src/cognito/postConfirmation.handler',
    //             environment:{ usersTable: usersTable.tableName },
    //             permissions:["dynamodb"]
    //         }
    //     }
    // })

    stack.addOutputs({
        SiteUrl:          site.url,
        ApiId:            api.apiId,
        ApiUrl:           api.url,
        ApiKey:           api.cdk.graphqlApi.apiKey || "",
        // UserPoolId:       auth.userPoolId,
        // UserPoolClientId: auth.userPoolClientId
    })
}