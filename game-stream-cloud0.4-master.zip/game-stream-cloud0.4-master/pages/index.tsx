import { Box, VStack } from '@chakra-ui/react'
import {AiOutlineDown} from 'react-icons/ai'

function Decor(){
  return(
    <Box position={'fixed'} minW={'99vw'} minH={'99vh'} zIndex={'-10'} display={'flex'} flexDir={'row'} justifyContent={'center'} pt={'20vh'} gap={'5vw'}>
      <Box borderRadius={'10vw'} minH={'2vw'} maxW={'50vw'} position={'fixed'} top={'40vh'} left={'0vw'}
           bg={'rgb(236, 68, 68)'} boxShadow={'0 0 3rem gold'} zIndex={'-20'} className='decor' transform={'scale(1)'} style={{animationDelay:'0ms'}}></Box>
      
      <Box borderRadius={'10vw'} minH={'2vw'} maxW={'50vw'} position={'fixed'} top={'50vh'} left={'30vw'}
           bg={'lightgreen'} boxShadow={'0 0 3rem lightgreen'} zIndex={'-20'} className='decor' transform={'scale(0.5)'} style={{animationDelay:'2000ms'}}></Box>

      <Box borderRadius={'10vw'} minH={'2vw'} maxW={'50vw'} position={'fixed'} top={'60vh'} left={'60vw'}
                bg={'lightblue'} boxShadow={'0 0 3rem lightblue'} zIndex={'-20'} className='decor' transform={'scale(0.25)'} style={{animationDelay:'4000ms'}}></Box>
      
      <Box minW={'100vw'} minH={'100vh'} position={'fixed'} top={'0'} left={'0'} overflowX={'hidden'}
           zIndex={'-10'} backdropFilter={'blur(20px)'} backgroundColor={'#00000022'}></Box>
    </Box>
  )
}

function Hero(){
  return(<VStack pt={'30vh'} minH={'80vh'}>
    <h1>Stream shared content</h1>
    <p>
      Stream content from devices on your network. Games are supported too🎮.
    </p>
    <AiOutlineDown fontSize={'1.5rem'} style={{position:'absolute', top:'85vh', left:'47vw'}} className='downArrow'/>
  </VStack>)
}

function PCStream(){
  return<VStack minH={'80vh'} gap={'2rem'}>
    <h1>Stream PC content</h1>
    <p>
      You don&apos;t need an insanely powerful computer to play your favourite game. Connect now and
      access awesome games and any other multimedia content streamed to your device now.
    </p>
    <p>
      *<strong>Multiplayer support coming soon!</strong> .. ideal for games like FIFA
    </p>
    <p>
      *<strong>Broadcast support coming soon!</strong> .. ideal for those who want to share multimedia content with
      more than 2 users.
    </p>
  </VStack>
}

function PSStream(){
  return<VStack minH={'80vh'} gap={'2rem'}>
    <h1>Stream PlayStation content</h1>
    <p>
      No need to rent a console for a whole night. Just play when you need to. No need to step out of your door(* depends
      on our coverage).
    </p>
    <p>
      *<strong>PlayStation 4 support coming soon!</strong>
    </p>
  </VStack>
}

function DeviceSupport(){
  return<VStack minH={'80vh'} gap={'2rem'}>
    <h1>Compatibility</h1>
    <p>
      We support all devices with a Web browser. For games, devices with the capability to connect to a
      gaming controller are recommended for gaming.
    </p>
    <p>
      This App works best with devices on the same local network. This has an advantage of not using the internet
      for network intensive tasks such as video streaming, this results in low data usage.
    </p>
    <p>
      *<strong>We support a wide range of controllers that can be recognized by the web browser.</strong>
    </p>
    <p>
      *<strong>We recommend a fast network.</strong>
    </p>
  </VStack>
}

function ServiceGuarantee(){
  return<VStack minH={'80vh'} gap={'2rem'}>
    <h1>Service Guarantee</h1>
    <p>
      We will rate stream providers to protect clients from poor streaming service quality.
    </p>
    <p>
      <strong>Service Interruption</strong> Users will have their streaming time counted, in-case of a connection failure, 
      the user will be able to continue with their streaming session later on.
    </p>
    <p>
      *<strong>We recommend a fast network.</strong>
    </p>
  </VStack>
}

export default function Home() {
  return (
    <>
      <Box p='5vw'>
        <Decor/>
        <Hero/>
        <PCStream/>
        <PSStream/>
        <DeviceSupport/>
        <ServiceGuarantee/>
      </Box>
    </>
  )
}
