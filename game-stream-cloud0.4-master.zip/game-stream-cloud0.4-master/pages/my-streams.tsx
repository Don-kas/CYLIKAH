import {Box, Flex, VStack, Text, Accordion, AccordionItem, AccordionButton, AccordionIcon, AccordionPanel} from '@chakra-ui/react'
import { useState } from 'react'

export default function MyStream(){
    return<VStack p='2rem'>
        <Accordion allowToggle>
            <AccordionItem>
                <h2>
                    <AccordionButton>
                        <Box as='div' minW={'90vw'} textAlign={'left'}>Stream Calculator</Box>
                        <AccordionIcon/>
                    </AccordionButton>
                </h2>
                <AccordionPanel>
                    <StreamCalculator/>
                </AccordionPanel>
            </AccordionItem>
            
        </Accordion>
    </VStack>
}

function StreamCalculator(){
    const [state, setState] = useState({
        hourlyRate:0,
        hourlyUsers:0,
        hoursCount:0,
        calculationReslut:0
    })

    function onInput(e: any){
        function calculationResult(hourlyRate: number, hourlyUsers: number, hoursCount: number){
            return hourlyRate * hourlyUsers * hoursCount
        }

        const fieldName = e.target.name

        switch(fieldName){
            case 'streamCalc/hourlyRate':
                let newState = {
                    ...state,
                }
                newState.hourlyRate = Number(e.target.value).valueOf()
                console.log(newState)
                const result = calculationResult(newState.hourlyRate, newState.hourlyUsers, newState.hoursCount)
                newState.calculationReslut = result
                console.log('result: '+result)
                setState({...newState})
                
                return
            case 'streamCalc/hourlyUserCount':
                let _newState = {
                    ...state,
                }
                _newState.hourlyUsers = Number(e.target.value).valueOf()
                console.log(_newState)
                const _result = calculationResult(_newState.hourlyRate, _newState.hourlyUsers, _newState.hoursCount)
                _newState.calculationReslut = _result
                console.log('result: '+_result)
                setState({..._newState})
                
                return
            case 'streamCalc/hoursCount':
                let newState_ = {
                    ...state,
                }
                newState_.hoursCount = Number(e.target.value).valueOf()
                console.log(newState_)
                const result_ = calculationResult(newState_.hourlyRate, newState_.hourlyUsers, newState_.hoursCount)
                newState_.calculationReslut = result_
                console.log('result: '+result_)
                setState({...newState_})

                return
            default:
                return
        }
    }

    return<VStack p={'2rem'}>
        <Box>
            <p>
                For games where the number of users is one, the single user will have to pay for the entire session.<br/>
                For games with 2 users, the two users will share the cost.
            </p>
            <p>
                <br/>
                *Broadcast sessions can support an indefinite number of users, only your network bandwith can limit
                the numbers of users or the stream quality.
            </p>
        </Box>
        <Flex gap={'1.2rem'} p='1' flexWrap={'wrap'}>
            <input placeholder='Hourly rate per user' type='number' name='streamCalc/hourlyRate' onInput={onInput}/>
            <input placeholder='Number of users per session' type="number" name='streamCalc/hourlyUserCount' onInput={onInput}/>
            <input placeholder='Number of hours' type='number' name='streamCalc/hoursCount' onInput={onInput}/>
            <div style={{paddingRight:'2rem'}}>Charges: Ksh. {Number(state.calculationReslut * .18).toFixed(2)} (fixed)</div>
            <div>
                <Text color={'var(--themeCol1)'} fontWeight={'600'}>Earnings(after charges): Ksh.{Number(state.calculationReslut * .82).toFixed(2)}</Text>
            </div>
        </Flex>
    </VStack>
}