import { VStack, Box, Switch } from "@chakra-ui/react";
import { Quicksand } from "next/font/google";
import { useEffect, useState } from "react";

const quicksand = Quicksand({weight:'600', subsets:['latin']})

enum StreamType{
    PC,
    PlayStation
}

export default function Play(){
    const [videoWidth, setVideoWidth] = useState(0)
    const [streamType, setStreamType] = useState(StreamType.PC)
    const [vControllerEnabled, setVControllerEnabled] = useState(false)
    
    function VideoElem(){
        
        function onResize(){
            setVideoWidth(window.innerWidth * .96)
        }
    
        useEffect(()=>{
            window.addEventListener('resize', onResize)
            onResize()
            return(()=>{
                window.removeEventListener('resize', onResize)
            })
        },[])
    
        return(<Box>
            <video controls width={videoWidth+'px'} style={{zIndex:'-10'}} autoPlay>
    
            </video>
        </Box>)
    }

    function VController(){
        function PCController(){
            return<Box>
                
            </Box>
        }
        function PSController(){
            return<Box>

            </Box>
        }
        if(vControllerEnabled){
            return(<Box position={'absolute'} top={'50vh'} width={'80vw'} maxW={'80rem'} border={'1px solid purple'}>
                {streamType === StreamType.PC ? <PCController/> : <PSController/>}
            </Box>)
        }else{
            return<></>
        }
    }

    return(<VStack pt='1rem' pb='1rem'>
        <Box>
            Enable on-screen controller?
            <Switch isChecked={vControllerEnabled} pl={'1rem'} onChange={()=>{setVControllerEnabled(!vControllerEnabled)}}/>
        </Box>
        <VideoElem/>
        <h1 className={quicksand.className}>Stream</h1>
        <VController/>
    </VStack>)
}