import '@/styles/globals.css'
import type { AppProps } from 'next/app'
import Navbar from '../react-components/Navbar'
import { ChakraProvider } from '@chakra-ui/react'
import Head from 'next/head'

export default function App({ Component, pageProps }: AppProps) {
  return <ChakraProvider>
      <Head>
        <title>tan9o</title>
      </Head>
      <Navbar/>
      <Component {...pageProps} />
  </ChakraProvider>
}
