import { SSTConfig } from "sst";
import Stack from './stacks/index'

export default {
  config(_input) {
    return {
      name: "gamestream04",
      region: "us-east-1",
      stage:'dev',
    };
  },
  // stacks(app) {
  //   app.stack(function Site({ stack }) {
  //     const site = new NextjsSite(stack, "site");

  //     stack.addOutputs({
  //       SiteUrl: site.url,
  //     });
  //   });
  // },
  stacks(app) {
    app.stack(Stack)
  },
} satisfies SSTConfig;
